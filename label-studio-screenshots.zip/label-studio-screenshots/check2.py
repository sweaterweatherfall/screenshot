import json
import pandas as pd

f = open("./project-7-at-2021-11-08-04-28-5259e82d.json")

json_file = json.load(f)

output = pd.DataFrame()
for i in json_file:
    full_text = i["Text"]
    parse_text = []
    parse_labels = []
    for j in i["label"]:
        parse_text.append(j["text"])
        for k in j["labels"]:
            parse_labels.append(k)
    output = output.append({"parse_text": " ".join(parse_text), "parse_labels": " ".join(parse_labels)}, ignore_index=True)

new_df.to_csv("./output_file_20211107.tsv", sep="\t")
